//
//  SHAppDelegate.h
//  Animation
//
//  Created by eason on 4/8/14.
//  Copyright (c) 2014 alibaba. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

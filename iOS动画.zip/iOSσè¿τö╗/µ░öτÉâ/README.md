AIMBalloon
==========

Examle code showing how to use UIDynamicAnimator in iOS 7. In addition it shows how to create CAShapeLayer which reacts to gravity.

<p align="center" >
  <img src="https://s3.amazonaws.com/cocoacontrols_production/uploads/control_image/image/1835/iOS_Simulator_Screen_shot_11_wrz_2013_22.27.50.png">
</p>

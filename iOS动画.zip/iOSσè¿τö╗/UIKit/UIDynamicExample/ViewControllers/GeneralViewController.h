#import <Foundation/Foundation.h>

@interface GeneralViewController : UIViewController
- (id)initWithViewName:(NSString *)aViewName andTitle:(NSString *)title;
@end
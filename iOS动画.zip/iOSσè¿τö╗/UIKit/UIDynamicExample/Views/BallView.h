#import <Foundation/Foundation.h>

@interface BallView : UIView
@end
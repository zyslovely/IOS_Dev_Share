#import <Foundation/Foundation.h>
#import "BaseViewWithBall.h"

@interface GravityView : BaseViewWithBall

@end
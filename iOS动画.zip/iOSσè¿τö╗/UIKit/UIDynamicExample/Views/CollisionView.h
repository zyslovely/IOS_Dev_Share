#import <Foundation/Foundation.h>
#import "BaseViewWithBall.h"

@interface CollisionView : BaseViewWithBall <UICollisionBehaviorDelegate>
@end
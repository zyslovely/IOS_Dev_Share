#import <Foundation/Foundation.h>

@interface BaseViewWithBall : UIView{
    UIView *ballView;
    UIDynamicAnimator *theAnimator;
}
@end
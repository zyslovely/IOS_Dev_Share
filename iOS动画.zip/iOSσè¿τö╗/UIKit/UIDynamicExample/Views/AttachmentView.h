#import <Foundation/Foundation.h>
#import "BaseViewWithBall.h"

@interface AttachmentView : BaseViewWithBall
@end
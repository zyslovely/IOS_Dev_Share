#import <Foundation/Foundation.h>

@interface SnapView : UIView
@end
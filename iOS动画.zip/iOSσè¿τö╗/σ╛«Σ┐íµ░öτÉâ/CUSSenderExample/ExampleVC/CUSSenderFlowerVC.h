//
//  CUSSenderFlowerVC.h
//  CUSSenderExample
//
//  Created by zhangyu on 14-2-25.
//  Copyright (c) 2014年 zhangyu. All rights reserved.
//

#import "CUSLayerVC.h"

@interface CUSSenderFlowerVC : CUSLayerVC

@end

//
//  CUSSenderFlowerLayer.h
//  CUSSenderExample
//
//  Created by zhangyu on 14-2-25.
//  Copyright (c) 2014年 zhangyu. All rights reserved.
//

#import "CUSSenderFallLayer.h"

@interface CUSSenderFlowerLayer : CUSSenderFallLayer

@end

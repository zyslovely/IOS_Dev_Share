CUSSender
=========

A iOS framework for particle emitter.Such as "i miss u" in WeChat.<br>
please pay attention to add Star, your support is my greatest motivation, thank you.<br>
To on github demand, advice and bugs.<br>

![image](https://github.com/JJMM/CUSResources/raw/master/CUSSenderIntr.gif)

## START

```objective-c
#import "CUSSender.h"

CALayer *layer = [[CUSSenderSnowLayer alloc]init];
[self.view.layer addSublayer:layer];
```
## All kinds

- CUSSenderStarLayer
- CUSSenderBirthdayLayer
- CUSSenderKissLayer
- CUSSenderGoldLayer
- CUSSenderSnowLayer
- CUSSenderRainLayer
- CUSSenderFlowerLayer


## License
CUSSender is available under the Apache 2.0 license. See the LICENSE file for more info.
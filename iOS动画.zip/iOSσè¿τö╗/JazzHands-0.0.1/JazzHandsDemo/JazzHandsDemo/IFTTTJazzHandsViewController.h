//
//  IFTTTJazzHandsViewController.h
//  JazzHandsDemo
//
//  Created by Devin Foley on 9/27/13.
//  Copyright (c) 2013 IFTTT Inc. All rights reserved.
//

#import "IFTTTJazzHands.h"

@interface IFTTTJazzHandsViewController : IFTTTAnimatedScrollViewController <UIScrollViewDelegate>

@end

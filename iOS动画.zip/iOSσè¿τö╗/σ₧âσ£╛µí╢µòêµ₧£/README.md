GLMoveToTrashAnimation
======================
Move to trash animation replica from Whatsapp.


Screenshots
------------
<img src="/demo.gif" />


### License
http://gautam.mit-license.org/

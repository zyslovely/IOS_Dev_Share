//
//  GLViewController.h
//  Animation
//
//  Created by Gautam Lodhiya on 13/09/13.
//  Copyright (c) 2013 Gautam Lodhiya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GLBucketCustomizationDemoVC : UIViewController
- (IBAction)playAnimation:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *playpausebutton;
@end

//
//  LetterPressExplosionTests.h
//  LetterPressExplosionTests
//
//  Created by Daniel Tavares on 28/03/2013.
//  Copyright (c) 2013 Daniel Tavares. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface LetterPressExplosionTests : SenTestCase

@end

//
//  LetterPressExplosionTests.m
//  LetterPressExplosionTests
//
//  Created by Daniel Tavares on 28/03/2013.
//  Copyright (c) 2013 Daniel Tavares. All rights reserved.
//

#import "LetterPressExplosionTests.h"

@implementation LetterPressExplosionTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in LetterPressExplosionTests");
}

@end

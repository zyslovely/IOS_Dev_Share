Letterpress-like explosion.

Category on `UIView` called Explode that will take the uiview and explode it into pieces.

    [myView lp_explode];

Not exactly the same as letterpress but will point people to the right direction.
